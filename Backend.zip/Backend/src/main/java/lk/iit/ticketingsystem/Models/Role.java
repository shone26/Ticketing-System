package lk.iit.ticketingsystem.Models;

public enum Role {
    CUSTOMER,
    VENDOR,
    ADMIN,
}
