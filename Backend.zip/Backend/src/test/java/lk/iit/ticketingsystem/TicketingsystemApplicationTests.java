package lk.iit.ticketingsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketingsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
