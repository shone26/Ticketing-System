import { Button } from "./components/ui/button";
import { LoginForm } from "./components/ui/login-form";
import SignInPage from "./pages/login page/sign-in-page";


function App() {
    return (

        <div>
      <SignInPage />
    </div>

    )
  }
  
  export default App;
  